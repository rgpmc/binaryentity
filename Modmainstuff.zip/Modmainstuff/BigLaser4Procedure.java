package net.mcreator.modjamfuturistic.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.phys.AABB;

import net.mcreator.modjamfuturistic.init.ModjamfuturisticModParticleTypes;
import net.mcreator.modjamfuturistic.entity.BinaryEntity;
import net.mcreator.modjamfuturistic.ModjamfuturisticMod;

import java.util.Comparator;
import java.util.List;

public class BigLaser4Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;

		// Set biglaser and BLACKHOLE true at start
		if (entity instanceof BinaryEntity _datEntSetL) {
			_datEntSetL.getEntityData().set(BinaryEntity.DATA_biglaser, true);
			_datEntSetL.getEntityData().set(BinaryEntity.DATA_BLACKHOLE, true);
		}

		double chestX = entity.getX();
		double chestY = entity.getY() + entity.getBbHeight() * 0.6;
		double chestZ = entity.getZ();

		int chargeTicks = 20;

		// Charging phase: swirl + slow ping
		for (int t = 0; t < chargeTicks; t++) {
			final int tickDelay = t;
			ModjamfuturisticMod.queueServerWork(tickDelay, () -> {
				if (!(entity.level() instanceof ServerLevel _level))
					return;

				double radius = 0.2 + 0.3 * (tickDelay / (double) chargeTicks);
				double heightOffset = 0.2 + 0.1 * (tickDelay / (double) chargeTicks);
				int particleCount = 1 + (tickDelay / 4);
				double angleStep = 2 * Math.PI / particleCount;

				for (int p = 0; p < particleCount; p++) {
					double angle = tickDelay * 0.3 + p * angleStep;
					double px = chestX + Math.cos(angle) * radius;
					double py = chestY + heightOffset;
					double pz = chestZ + Math.sin(angle) * radius;
					_level.sendParticles((SimpleParticleType) ModjamfuturisticModParticleTypes.LASERP.get(), px, py, pz, 1, 0, 0, 0, 0);
				}

				if (tickDelay % 4 == 0) {
					if (world instanceof Level _lvl) {
						if (!_lvl.isClientSide()) {
							_lvl.playSound(null, BlockPos.containing(chestX, chestY, chestZ),
									BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.arrow.hit_player")),
									SoundSource.HOSTILE, 0.5f, 1f);
						} else {
							_lvl.playLocalSound(chestX, chestY, chestZ,
									BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.arrow.hit_player")),
									SoundSource.HOSTILE, 0.5f, 1f, false);
						}
					}
				}

				// Rotate Binary toward nearest target
				LivingEntity target = world.getEntitiesOfClass(LivingEntity.class,
						AABB.ofSize(entity.position(), 32, 32, 32), e -> e != entity)
						.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(entity))).orElse(null);

				if (target != null) {
					float yaw = (float) (Math.atan2(target.getZ() - entity.getZ(), target.getX() - entity.getX()) * 180 / Math.PI) - 90f;
					float pitch = (float) -(Math.atan2((target.getY() + target.getBbHeight() / 2) - entity.getY(),
							Math.sqrt(Math.pow(target.getX() - entity.getX(), 2) + Math.pow(target.getZ() - entity.getZ(), 2))) * 180 / Math.PI);

					entity.setYRot(yaw);
					entity.setXRot(pitch);
					if (entity instanceof Mob mob) {
						mob.yBodyRot = mob.getYRot();
						mob.yHeadRot = mob.getYRot();
					}
				}
			});
		}

		// Fire laser after charge
		ModjamfuturisticMod.queueServerWork(chargeTicks, () -> fireLaser(world, entity));
	}

	private static void fireLaser(LevelAccessor world, Entity entity) {
		if (!(entity.level() instanceof ServerLevel _level))
			return;

		LivingEntity target = world.getEntitiesOfClass(LivingEntity.class,
				AABB.ofSize(entity.position(), 32, 32, 32), e -> e != entity)
				.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(entity))).orElse(null);

		if (target == null)
			return;

		double offsetX = (Math.random() - 0.5) * 8.0;
		double offsetY = (Math.random() - 0.5) * 4.0;
		double offsetZ = (Math.random() - 0.5) * 8.0;

		final double[] aimX = { target.getX() + offsetX };
		final double[] aimY = { target.getY() + target.getBbHeight() / 2 + offsetY };
		final double[] aimZ = { target.getZ() + offsetZ };

		for (int i = 0; i < 135; i++) {
			final int tickDelay = i;
			ModjamfuturisticMod.queueServerWork(tickDelay, () -> {
				if (!(entity.level() instanceof ServerLevel _level2))
					return;

				double trackingFactor = 0.08;
				aimX[0] += (target.getX() - aimX[0]) * trackingFactor;
				aimY[0] += ((target.getY() + target.getBbHeight() / 2) - aimY[0]) * trackingFactor;
				aimZ[0] += (target.getZ() - aimZ[0]) * trackingFactor;

				double originX = entity.getX();
				double originY = entity.getY() + entity.getBbHeight() * 0.6;
				double originZ = entity.getZ();

				double dx = aimX[0] - originX;
				double dy = aimY[0] - originY;
				double dz = aimZ[0] - originZ;

				float yaw = (float) (Math.atan2(dz, dx) * 180 / Math.PI) - 90f;
				float pitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180 / Math.PI);

				entity.setYRot(yaw);
				entity.setXRot(pitch);
				if (entity instanceof Mob mob) {
					mob.yBodyRot = mob.getYRot();
					mob.yHeadRot = mob.getYRot();
				}

				double shorten = 0.99;
				double beamX = dx * shorten;
				double beamY = dy * shorten;
				double beamZ = dz * shorten;

				double distance = Math.sqrt(beamX * beamX + beamY * beamY + beamZ * beamZ);
				double step = 0.1;
				int steps = Math.max(1, (int) (distance / step));

				for (int j = 0; j <= steps; j++) {
					double fraction = j / (double) steps;
					double px = originX + beamX * fraction;
					double py = originY + beamY * fraction;
					double pz = originZ + beamZ * fraction;
					_level2.sendParticles((SimpleParticleType) ModjamfuturisticModParticleTypes.LASERP.get(), px, py, pz, 1, 0, 0, 0, 0);
				}

				if (world instanceof Level _lvl) {
					if (!_lvl.isClientSide()) {
						_lvl.playSound(null, BlockPos.containing(originX, originY, originZ),
								BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.arrow.hit_player")),
								SoundSource.HOSTILE, 0.7f, 1.2f);
					} else {
						_lvl.playLocalSound(originX, originY, originZ,
								BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.arrow.hit_player")),
								SoundSource.HOSTILE, 0.7f, 1.2f, false);
					}
				}

				List<LivingEntity> nearby = world.getEntitiesOfClass(LivingEntity.class,
						AABB.ofSize(new net.minecraft.world.phys.Vec3(originX + beamX, originY + beamY, originZ + beamZ), 2.5, 2.5, 2.5));
				for (LivingEntity e : nearby) {
					if (e != entity) {
						DamageSource src = _level2.damageSources().source(DamageTypes.MAGIC);
						e.hurt(src, 4.5F);
					}
				}
			});
		}

		// Stop laser: set biglaser and BLACKHOLE false
		ModjamfuturisticMod.queueServerWork(135, () -> {
			if (entity instanceof BinaryEntity _datEntSetL) {
				_datEntSetL.getEntityData().set(BinaryEntity.DATA_biglaser, false);
				_datEntSetL.getEntityData().set(BinaryEntity.DATA_BLACKHOLE, false);
			}
		});
	}
}
