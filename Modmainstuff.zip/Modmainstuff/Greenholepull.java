package net.mcreator.modjamfuturistic.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.modjamfuturistic.entity.BinaryEntity;
import net.mcreator.modjamfuturistic.init.ModjamfuturisticModParticleTypes;

import java.util.List;

public class GreenholepullProcedure {
    /**
     * Called every tick (server side) while the greenhole entity is active.
     *
     * @param world        LevelAccessor (should be server-level)
     * @param x            center x of greenhole
     * @param y            center y of greenhole
     * @param z            center z of greenhole
     * @param sourceEntity the greenhole / Binary sub-entity that spawned this effect
     */
    public static void execute(LevelAccessor world, double x, double y, double z, Entity sourceEntity) {
        if (sourceEntity == null) return;
        if (!(world instanceof ServerLevel _level)) return; // only run on server

        // CONFIG
        double pullRadius = 15.0;    // how far the pull reaches
        double maxPullStep = 0.3;    // maximum teleport/translation step per tick (blocks) when very close
        double basePull = 0.10;      // base pull applied at long range
        double damageRadius = 1.0;   // only damage inside this radius
        float damageAmount = 9.0f;   // magic damage applied on collision

        // find all entities inside the pull radius, excluding the source Binary
        AABB searchBox = new AABB(x - pullRadius, y - pullRadius, z - pullRadius, x + pullRadius, y + pullRadius, z + pullRadius);
        List<Entity> entities = world.getEntitiesOfClass(Entity.class, searchBox, e -> e != sourceEntity && !(e instanceof BinaryEntity));

        for (Entity e : entities) {
            // vector from entity to center
            Vec3 toCenter = new Vec3(x - e.getX(), y - e.getY(), z - e.getZ());
            double dist = toCenter.length();

            if (dist <= 0.001) {
                // already at center — skip pull
            } else {
                // Strength: increases as entity gets closer (inverse-ish)
                // normalized in [0..1] where 1 is at center
                double closeness = Math.max(0.0, 1.0 - (dist / pullRadius)); // 0 far, 1 near
                // compute a per-tick step: basePull + closeness*(maxPullStep - basePull)
                double pullStep = basePull + closeness * (maxPullStep - basePull);

                // Direction normalized
                Vec3 dir = toCenter.normalize();

                // Pull vector to apply this tick
                Vec3 pullVec = dir.scale(pullStep);

                // If ServerPlayer, teleport small step to avoid client-server motion fights
                if (e instanceof ServerPlayer sp) {
                    // compute target teleport pos (clamped so we don't snap through)
                    double newX = sp.getX() + pullVec.x;
                    double newY = sp.getY() + pullVec.y;
                    double newZ = sp.getZ() + pullVec.z;

                    // Clamp vertical teleport to avoid teleporting into blocks — you might add raytrace here if needed
                    sp.teleportTo(newX, newY, newZ);
                    sp.fallDistance = 0f;
                } else {
                    // Non-player entities: apply velocity and also move immediately
                    // Add a scaled velocity so entity is pulled strongly
                    e.setDeltaMovement(e.getDeltaMovement().add(pullVec));
                    // mark impulse and move so it acts right now
                    try {
                        e.move(net.minecraft.world.entity.MoverType.SELF, e.getDeltaMovement());
                    } catch (Exception ex) {
                        // some entities may not like move + delta; ignore errors
                        e.setDeltaMovement(e.getDeltaMovement());
                    }
                }
            }

            // Visual: particle on the entity (small swirl)
            double px = e.getX() + (Math.random() - 0.5) * 0.4;
            double py = e.getY() + 0.2 + Math.random() * 0.4;
            double pz = e.getZ() + (Math.random() - 0.5) * 0.4;
            _level.sendParticles((SimpleParticleType) ModjamfuturisticModParticleTypes.LASERP.get(), px, py, pz, 1, 0, 0, 0, 0);

            // Damage only if within damageRadius of the center
            if (e instanceof LivingEntity living && e.distanceToSqr(x, y, z) <= damageRadius * damageRadius) {
                living.hurt(_level.damageSources().source(DamageTypes.MAGIC), damageAmount);
            }
        }

        // low-frequency ambient sound to indicate the field (optional: you can throttle this)
        if (_level.getGameTime() % 20L == 0L) { // once per second
            _level.playSound(null, BlockPos.containing(x, y, z),
                    BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.end_portal.spawn")),
                    SoundSource.HOSTILE, 0.5f, 1.0f);
        }
    }
}
