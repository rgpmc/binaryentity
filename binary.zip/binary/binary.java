package net.mcreator.modjamfuturistic.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.AABB;

import net.mcreator.modjamfuturistic.procedures.BigLaser4Procedure;
import net.mcreator.modjamfuturistic.entity.LaserblaserEntity;

public class BinaryEntity extends Monster {
    public static final EntityDataAccessor<Boolean> DATA_biglaser = SynchedEntityData.defineId(BinaryEntity.class, EntityDataSerializers.BOOLEAN);
    public static final EntityDataAccessor<Boolean> DATA_BLACKHOLE = SynchedEntityData.defineId(BinaryEntity.class, EntityDataSerializers.BOOLEAN);

    public BinaryEntity(EntityType<? extends BinaryEntity> type, Level world) {
        super(type, world);
        this.xpReward = 100;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_biglaser, false);
        this.entityData.define(DATA_BLACKHOLE, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 1.0));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount % 400 == 0) {
            BigLaser4Procedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), this);
        }
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (target instanceof LaserblaserEntity) return false;
        return super.canAttack(target);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 600.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 10.0)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return super.hurt(source, amount);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions size) {
        return 2.2F;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Blackhole", this.entityData.get(DATA_BLACKHOLE));
        tag.putBoolean("Biglaser", this.entityData.get(DATA_biglaser));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_BLACKHOLE, tag.getBoolean("Blackhole"));
        this.entityData.set(DATA_biglaser, tag.getBoolean("Biglaser"));
    }
}
